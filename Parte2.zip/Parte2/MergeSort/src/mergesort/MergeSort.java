package mergesort;

import java.util.Random;

public class MergeSort {

    public static void main(String[] args) {
        int size = 30;
        int list[] = new int [size];
        Random r = new Random();
        int num = size * 11;
        
        //preencher o vetor
        for(int i = 0; i < size; i++){
            list[i] = r.nextInt(num) + 1;   
        }
        //imprimir o vetor
        System.out.println("Vetor desordenado: ");
        for(int vetor: list){
            System.out.print(vetor + " ");
        }
        System.out.println("");
        mergeSort(list, size);
        System.out.println("\nAlgoritmo MergeSort");
        System.out.println("Vetor Ordenado");
          
        for (int ordem: list){
            System.out.print(ordem + " ");
        }
    }
    
    public static void merge(int[] left_arr,int[] right_arr, int[] arr,int left_size, int right_size){
      
      int i = 0, e = 0, d = 0;

      while(e < left_size && d < right_size){
          
          if(left_arr[e] < right_arr[d]){
              arr[i++] = left_arr[e++];
          }
          else{
              arr[i++] = right_arr[d++];
          }
      }
      while(e < left_size){
          arr[i++] = left_arr[e++];
      }
      while(d < right_size){
        arr[i++] = right_arr[d++];
      }
  }
    
    public static void mergeSort(int [] arr, int tam){
      if (tam < 2){
        return;
		}
      
      int mid = tam / 2;
      int [] left_arr = new int[mid];
      int [] right_arr = new int[tam-mid];
      
    //Dividindo o Array em 2
      int j = 0;
      for(int i = 0;i < tam; ++i){
          if(i < mid){
              left_arr[i] = arr[i];
          }
          else{
              right_arr[j] = arr[i];
              j = j + 1;
          }
      }
      mergeSort(left_arr, mid);
      mergeSort(right_arr, tam-mid);
	  
      
      merge(left_arr, right_arr, arr, mid, tam-mid);
  }
}

