package quicksort;

import java.util.Random;


public class QuickSort {

        public static void main(String[] args) {
        
        int size = 30;
        int list[] = new int [size];
        Random r = new Random();
        int num = size * 11;
        
        //preencher o vetor
        for(int i = 0; i < size; i++){
            list[i] = r.nextInt(num) + 1;   
        }
        //imprimir o vetor
        System.out.println("Vetor desordenado: ");
        for(int vetor: list){
            System.out.print(vetor + " ");
        }
        System.out.println("");
        
         //quicksort
        qSort(list, 0, size - 1);

        System.out.println("\nAlgoritmo quick Sort");
        System.out.println("Vetor Ordenado:");
        for (int ordem : list) {
            System.out.print(ordem + " ");
        }
    
    }
    public static int partition(int arr[], int low, int high) {
        int pivot = arr[high];
        int i = (low - 1);

        for (int j = low; j <= high - 1; j++) {
            if (arr[j] <= pivot) {
                i++;

                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }

        }

        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        return i + 1;
    }

    public static void qSort(int arr[], int low, int high) {
        if (low < high) {

            int pi = partition(arr, low, high);

            qSort(arr, low, pi - 1);
            qSort(arr, pi + 1, high);
        }
    } 
}
       
