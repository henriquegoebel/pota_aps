package insertionsort;

import java.util.Random;


public class InsertionSort {

  
    public static void main(String[] args) {
        //criar um vetor aleatório
        int size = 10; //tamanho do vetor
        int list[] = new int [size];
        
        Random r = new Random();
        int num = size * 12;
                
        //povoar o meu vetor
        for(int i = 0; i < size; i++){
            list[i] = r.nextInt(num);
        }
        
        //imprimir o vetor na tela
        System.out.println("Vetor desordenado");
        for(int vetor : list){
            System.out.print(vetor + " ");
        }
        System.out.println("");
        
        //algoritmo Insertion Sort
        int iter = 0;
        for(int i = 1; i < list.length; i++){
            int key = list[i];
            int j = i-1;
            while(j >= 0 && key < list[j]){
                iter++;
                int aux = list[j];
                list[j] = list[j+1];
                list[j+1] = aux;
                j--;
            }
        }
        System.out.println("\nAlgoritmo Insertion Sort");
        System.out.println("Vetor Ordenado");
        for(int ordem : list){
            System.out.print(ordem + " ");
        }
        System.out.println("\nNúmero de iterações: " + iter);
        
    }
    
}
