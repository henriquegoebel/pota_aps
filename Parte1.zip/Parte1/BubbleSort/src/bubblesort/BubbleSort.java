package bubblesort;

import java.util.Random;

public class BubbleSort {

    public static void main(String[] args) {
        //criar um vetor aleatório
        int size = 10; //tamanho do vetor
        int list[] = new int [size];
        
        Random r = new Random();
        int num = size * 12;
                
        //povoar o meu vetor
        for(int i = 0; i < size; i++){
            list[i] = r.nextInt(num);
        }
        
        //imprimir o vetor na tela
        System.out.println("Vetor desordenado");
        for(int vetor : list){
            System.out.print(vetor + " ");
        }
        System.out.println("");
        
        //algoritmo Bubble Sort
        int aux; 
        boolean ordenado;
        int iter = 0;
        
        for(int i = 0; i < list.length; i++){
            ordenado = true;
            
            for(int j = 0; j < (list.length - 1); j++){
                iter++;
                if(list[j] > list[j+1]){ //compara com o do lado
                    aux = list[j]; //usando auxiliar para trocar de posição (esq para aux)
                    list[j] = list[j+1]; // dir para esq
                    list[j+1] = aux; //dir recebe aux
                    ordenado = false;
                }
            }
            if(ordenado){
                break;
            }
        }
        System.out.println("\nAlgoritmo Bubble Sort");
        System.out.print("Imprimindo o vetor ordenado\n");
        
        for(int ordem : list){
            System.out.print(ordem + " ");
        }
        System.out.println("\nNúmero de Iterações: " + iter);
        
        
        System.out.println("");
        System.out.println("");
        System.out.println("");
        
        
        
    }
    
    
    
    
    public static void gerarVetor (int size){
        
        int list[] = new  int [size];
        
        Random r = new Random();
        int num = size * 12;
                
        //povoar o meu vetor
        for(int i = 0; i < size; i++){
            list[i] = r.nextInt(num);
        }
        
        //imprimir o vetor na tela
        System.out.println("Vetor desordenado");
        for(int vetor : list){
            System.out.print(vetor + " ");
        }
        System.out.println("");
        
        
    }
    
    public static void bubbleSort(int list[]){
    //algoritmo Bubble Sort
        int aux; 
        boolean ordenado;
        int iter = 0;
        
        for(int i = 0; i < list.length; i++){
            ordenado = true;
            
            for(int j = 0; j < (list.length - 1); j++){
                iter++;
                if(list[j] > list[j+1]){ //compara com o do lado
                    aux = list[j]; //usando auxiliar para trocar de posição (esq para aux)
                    list[j] = list[j+1]; // dir para esq
                    list[j+1] = aux; //dir recebe aux
                    ordenado = false;
                }
            }
            if(ordenado){
                break;
            }
        }
        System.out.println("\nAlgoritmo Bubble Sort");
        System.out.print("Imprimindo o vetor ordenado\n");
        
        for(int ordem : list){
            System.out.print(ordem + " ");
        }
        System.out.println("\nNúmero de Iterações: " + iter);
    }
}
