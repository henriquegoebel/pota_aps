package selectionsort;

import java.util.Random;

public class SelectionSort {

    public static void main(String[] args) {
        //criar um vetor aleatório
        int size = 10; //tamanho do vetor
        int list[] = new int [size];
        
        
        Random r = new Random();
        int num = size * 12;
                
        //povoar o meu vetor
        for(int i = 0; i < size; i++){
            list[i] = r.nextInt(num);
        }
        
        //imprimir o vetor na tela
        System.out.println("Vetor desordenado");
        for(int vetor : list){
            System.out.print(vetor + " ");
        }
        System.out.println("");
        
        //algoritmo Selection Sort
        int iter1 = 0;
        int iter2 = 0;
        int aux = 0;
        int i, j, minValue, minIndex;
        for(i = 0; i < list.length; i++){
            minValue = list[i];
            minIndex = i;
            for(j = i; j < list.length; j++){
                iter1++;
                if(list[j] < minValue){
                    minValue = list[j];
                    minIndex = j;
                }
            }
            if(minValue < list[i]){
                iter2++;
                aux = list[i];
                list[i] = list[minIndex];
                list[minIndex] = aux;
            }
        }
        System.out.println("\nAlgoritmo Selection Sort");
        System.out.println("Vetor Ordenado");
        for(int ordem : list){
            System.out.print(ordem + " ");
        }
        System.out.println("\nNúmero de Iterações: " + (iter1+iter2));
    }
    
}
