package heapsort;

import java.util.Random;

public class HeapSort {
    public static void main(String[] args) {
        int size = 30;
        int list[] = new int [size];
        Random r = new Random();
        int num = size * 11;
        
        //preencher o vetor
        for(int i = 0; i < size; i++){
            list[i] = r.nextInt(num) + 1;   
        }
        //imprimir o vetor
        System.out.println("Vetor desordenado: ");
        for(int vetor: list){
            System.out.print(vetor + " ");
        }
        System.out.println("");
        
        
        //imprimir ordenado
        System.out.println("\nAlgoritmo HeapSort");
        System.out.println("Vetor Ordenado");
        heapSort(list, size);
        
        for (int ordem: list){
            System.out.print(ordem + " ");
        }
        
    }
    //algoritmo HearSort
    public static void heapSort(int arr[], int size){
        criarHeap(arr,size);
        
        for(int i = size - 1; i > 0; i--){

            //troca a raiz com o último
            swap(arr, 0, i);
            
            //refaz o heap na árvore toda
            int j = 0, index;
            do{
                index = (2 * j + 1);

                if(index < (i-1) && arr[index] < arr[index + 1]){
                    index++;
                } 
                //se a raiz for menor que o filho
                //troca de lugar
                if(index < i && arr[j] < arr[index]){
                    swap(arr, j, index);
                   
                }
                j = index;
            } while(index < 1);
        }
    }
    
    
    public static void criarHeap(int arr[], int size){
        int iter = 0;
        for(int i = 1; i < size; i++){
            //verifica se filho maior que pai
            if(arr[i] > arr[(i-1) /2]){
                int j = i;
                //troca pai com o filho enquanto for menor
                while(arr[j] > arr[(j-1) /2]){
                    iter++;
                    swap(arr, j, (j-1)/2);
                    j = (j - 1)/2;
                    
                }
            }
        }System.out.println("iterações: " + iter);
    }
    
    public static void swap(int[] v, int i, int j){
        int temp = v[i];
        v[i] = v[j];
        v[j] = temp;
    }
}
